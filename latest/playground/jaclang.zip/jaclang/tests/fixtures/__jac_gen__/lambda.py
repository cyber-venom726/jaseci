from __future__ import annotations
from jaclang import *
d = JacList([{'name': 'a', 'value': 105}, {'name': 'b', 'value': 22}, {'name': 'c', 'value': 33}, {'name': 'd', 'value': 2}, {'name': 'e', 'value': 11}])
d.sort(key=lambda x: int: x['value'], reverse=True)
print(d)